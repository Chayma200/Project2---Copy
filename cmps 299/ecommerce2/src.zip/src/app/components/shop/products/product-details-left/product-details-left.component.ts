import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-product-details-left',
  templateUrl: './product-details-left.component.html',
  styleUrls: ['./product-details-left.component.sass']
})
export class ProductDetailsLeftComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
