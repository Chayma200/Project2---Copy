import { Component, EventEmitter, Input, OnInit, Output, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { PersonalInventoryService } from './personal-inventory.service';


@Component({
  selector: 'app-personal-inventory',
  templateUrl: './personal-inventory.component.html',
  styleUrls: ['./personal-inventory.component.sass']
})
export class PersonalInventoryComponent implements OnInit {

  allitems: {};

  constructor(private router: Router, private perInService: PersonalInventoryService) { }

  ngOnInit() {
    this.perInService.getPersonalInventoryItems("Chayma's Store", -1, -1).subscribe(data => { this.allitems = data; console.log(this.allitems); });
  }
}
