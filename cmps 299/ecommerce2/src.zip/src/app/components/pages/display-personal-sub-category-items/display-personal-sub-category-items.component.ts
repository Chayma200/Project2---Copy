import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { PersonalInventoryService } from '../my-account/personal-inventory/personal-inventory.service';

@Component({
  selector: 'app-display-personal-sub-category-items',
  templateUrl: './display-personal-sub-category-items.component.html',
  styleUrls: ['./display-personal-sub-category-items.component.sass']
})
export class DisplayPersonalSubCategoryItemsComponent implements OnInit {

  subcategoryItems: {};
  categoryId: number;
  subcategoryId: number;
  constructor(private route: ActivatedRoute, private perInService: PersonalInventoryService) { }

  ngOnInit(): void {
    let catId = parseInt(this.route.snapshot.paramMap.get("categoryId"));
    let subcatId = parseInt(this.route.snapshot.paramMap.get("subcategoryId"));

    this.categoryId = catId;
    this.subcategoryId = subcatId;
    this.perInService.getPersonalInventorySubCategoriesItems("Chayma's Store", this.categoryId, this.subcategoryId).subscribe(data => { this.subcategoryItems = data; console.log(this.subcategoryItems); });
  }

}
