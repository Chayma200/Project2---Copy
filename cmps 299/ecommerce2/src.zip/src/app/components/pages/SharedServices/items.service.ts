import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ItemsService {
  url = "http://localhost:8342/";
  constructor(private http: HttpClient) { }

  getAllItems(catID: number, subCatID: number) {
    return this.http.get(`${this.url}api/Items/GetAllItems/${catID}/${subCatID}`);
  }

  //getAllCategoryItems(catID: number, subCatID: number) {
  //  return this.http.get(`${this.url}api/Items/GetAllItems/${catID}/${subCatID}`);
  //}

  //getAllSubcategoryItems(catID: number, subCatID: number) {
  //  return this.http.get(`${this.url}api/Items/GetAllItems/${catID}/${subCatID}`);
  //}
}
