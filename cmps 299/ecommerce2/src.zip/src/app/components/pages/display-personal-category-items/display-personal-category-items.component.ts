import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { PersonalInventoryService } from '../my-account/personal-inventory/personal-inventory.service';

@Component({
  selector: 'app-display-personal-category-items',
  templateUrl: './display-personal-category-items.component.html',
  styleUrls: ['./display-personal-category-items.component.sass']
})
export class DisplayPersonalCategoryItemsComponent implements OnInit {
  categoryItems: {};
  categoryId: number;
  constructor(private route: ActivatedRoute, private perInService: PersonalInventoryService) { }

  ngOnInit(): void {
    let catId = parseInt(this.route.snapshot.paramMap.get("categoryId"));

    this.categoryId = catId;

    this.perInService.getPersonalInventorySubCategoriesItems("Chayma's Store", this.categoryId, -1).subscribe(data => { this.categoryItems = data; console.log(this.categoryItems); });
  }

}
