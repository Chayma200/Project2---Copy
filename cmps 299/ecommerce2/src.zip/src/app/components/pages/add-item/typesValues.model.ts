import { FormControl } from '@angular/forms';

export class typesValues {
  CharType: string;
  CharValue: string;
}
