import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-basic-radio',
  templateUrl: './basic-radio.component.html',
  styleUrls: ['./basic-radio.component.scss']
})
export class BasicRadioComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
