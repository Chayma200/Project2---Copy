import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-basic-divider',
  templateUrl: './basic-divider.component.html',
  styleUrls: ['./basic-divider.component.scss']
})
export class BasicDividerComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
