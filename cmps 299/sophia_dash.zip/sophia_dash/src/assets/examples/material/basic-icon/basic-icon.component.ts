import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-basic-icon',
  templateUrl: './basic-icon.component.html',
  styleUrls: ['./basic-icon.component.scss']
})
export class BasicIconComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
