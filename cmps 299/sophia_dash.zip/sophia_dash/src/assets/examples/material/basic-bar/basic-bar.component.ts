import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-basic-bar',
  templateUrl: './basic-bar.component.html',
  styleUrls: ['./basic-bar.component.scss']
})
export class BasicBarComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
