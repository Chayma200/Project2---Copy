export interface User {
  id?: string;
  displayName?: string;
  emailAddress?: string,
  role?: string
}