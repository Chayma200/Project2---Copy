export class InboxDB {
  public messages = [
    {
      sender: {
        name: 'Marko Apostolski',
        photo: 'assets/images/face-1.jpg'
      },
      date: new Date('3/14/2020'),
      selected: false,
      subject: 'Welcome to Angular sophia',
      message: `<p>Natus consequuntur perspiciatis esse beatae illo quos eaque.</p>
            <p>Earum, quisquam, fugit? Numquam dolor magni nisi? Suscipit odit, ipsam iusto enim culpa, 
            temporibus vero possimus error voluptates sequi. Iusto ipsam, nihil? Eveniet modi maxime animi excepturi a dignissimos doloribus, 
            inventore sed ratione, ducimus atque earum maiores tenetur officia commodi dicta tempora consequatur non nesciunt ipsam, 
            consequuntur quia fuga aspernatur impedit et? Natus, earum.</p>
            <blockquote>
            Earum, quisquam, fugit? Numquam dolor magni nisi? Suscipit odit, ipsam iusto enim culpa, 
            temporibus vero possimus error voluptates sequi.
            </blockquote>
            <p>Earum, quisquam, fugit? Numquam dolor magni nisi? Suscipit odit, ipsam iusto enim culpa, 
            temporibus vero possimus error voluptates sequi. Iusto ipsam, nihil? Eveniet modi maxime animi excepturi a dignissimos doloribus, 
            inventore sed ratione, ducimus atque earum maiores tenetur officia commodi dicta tempora consequatur non nesciunt ipsam, 
            consequuntur quia fuga aspernatur impedit et? Natus, earum.</p><br>
            Thanks<br>
            Jhone`
    },
    {
      sender: {
        name: 'Marko Apostolski',
        photo: 'assets/images/face-2.jpg'
      },
      date: new Date('11/12/2020'),
      selected: false,
      subject: 'Confirm your email address',
      message: `<p>Natus consequuntur perspiciatis esse beatae illo quos eaque.</p>
            <p>Earum, quisquam, fugit? Numquam dolor magni nisi? Suscipit odit, ipsam iusto enim culpa, 
            temporibus vero possimus error voluptates sequi. Iusto ipsam, nihil? Eveniet modi maxime animi excepturi a dignissimos doloribus, 
            inventore sed ratione, ducimus atque earum maiores tenetur officia commodi dicta tempora consequatur non nesciunt ipsam, 
            consequuntur quia fuga aspernatur impedit et? Natus, earum.</p>
            <blockquote>
            Earum, quisquam, fugit? Numquam dolor magni nisi? Suscipit odit, ipsam iusto enim culpa, 
            temporibus vero possimus error voluptates sequi.
            </blockquote>
            <p>Earum, quisquam, fugit? Numquam dolor magni nisi? Suscipit odit, ipsam iusto enim culpa, 
            temporibus vero possimus error voluptates sequi. Iusto ipsam, nihil? Eveniet modi maxime animi excepturi a dignissimos doloribus, 
            inventore sed ratione, ducimus atque earum maiores tenetur officia commodi dicta tempora consequatur non nesciunt ipsam, 
            consequuntur quia fuga aspernatur impedit et? Natus, earum.</p>
            <blockquote>
            Earum, quisquam, fugit? Numquam dolor magni nisi? Suscipit odit, ipsam iusto enim culpa, 
            temporibus vero possimus error voluptates sequi.
            </blockquote><br>
            Thanks<br>
            Mark`

    },
    {
      sender: {
        name: 'Tony Adonald',
        photo: 'assets/images/face-3.jpg'
      },
      date: new Date('1/20/2020'),
      selected: false,
      subject: 'New order informations',
      message: `<p>Natus consequuntur perspiciatis esse beatae illo quos eaque.</p>
            <p>Earum, quisquam, fugit? Numquam dolor magni nisi? Suscipit odit, ipsam iusto enim culpa, 
            temporibus vero possimus error voluptates sequi. Iusto ipsam, nihil? Eveniet modi maxime animi excepturi a dignissimos doloribus, 
            inventore sed ratione, ducimus atque earum maiores tenetur officia commodi dicta tempora consequatur non nesciunt ipsam, 
            consequuntur quia fuga aspernatur impedit et? Natus, earum.</p>
            <blockquote>
            Earum, quisquam, fugit? Numquam dolor magni nisi? Suscipit odit, ipsam iusto enim culpa, 
            temporibus vero possimus error voluptates sequi.
            </blockquote>
            <p>Earum, quisquam, fugit? Numquam dolor magni nisi? Suscipit odit, ipsam iusto enim culpa, 
            temporibus vero possimus error voluptates sequi. Iusto ipsam, nihil? Eveniet modi maxime animi excepturi a dignissimos doloribus, 
            inventore sed ratione, ducimus atque earum maiores tenetur officia commodi dicta tempora consequatur non nesciunt ipsam, 
            consequuntur quia fuga aspernatur impedit et? Natus, earum.</p><br>
            Thanks<br>
            Jhone`

    },
    {
      sender: {
        name: 'Sofi Apostolska',
        photo: 'assets/images/face-1.jpg'
      },
      date: new Date('7/9/2020'),
      selected: false,
      subject: 'Welcome to Angular sophia',
      message: `<p>Natus consequuntur perspiciatis esse beatae illo quos eaque.</p>
            <p>Earum, quisquam, fugit? Numquam dolor magni nisi? Suscipit odit, ipsam iusto enim culpa, 
            temporibus vero possimus error voluptates sequi. Iusto ipsam, nihil? Eveniet modi maxime animi excepturi a dignissimos doloribus, 
            inventore sed ratione, ducimus atque earum maiores tenetur officia commodi dicta tempora consequatur non nesciunt ipsam, 
            consequuntur quia fuga aspernatur impedit et? Natus, earum.</p>
            <blockquote>
            Earum, quisquam, fugit? Numquam dolor magni nisi? Suscipit odit, ipsam iusto enim culpa, 
            temporibus vero possimus error voluptates sequi.
            </blockquote>
            <p>Earum, quisquam, fugit? Numquam dolor magni nisi? Suscipit odit, ipsam iusto enim culpa, 
            temporibus vero possimus error voluptates sequi. Iusto ipsam, nihil? Eveniet modi maxime animi excepturi a dignissimos doloribus, 
            inventore sed ratione, ducimus atque earum maiores tenetur officia commodi dicta tempora consequatur non nesciunt ipsam, 
            consequuntur quia fuga aspernatur impedit et? Natus, earum.</p><br>
            Thanks<br>
            Jhone`
    },
    {
      sender: {
        name: 'Elena Ravnjanski',
        photo: 'assets/images/face-2.jpg'
      },
      date: new Date('10/3/2020'),
      selected: false,
      subject: 'Confirm your email address',
      message: `<p>Natus consequuntur perspiciatis esse beatae illo quos eaque.</p>
            <p>Earum, quisquam, fugit? Numquam dolor magni nisi? Suscipit odit, ipsam iusto enim culpa, 
            temporibus vero possimus error voluptates sequi. Iusto ipsam, nihil? Eveniet modi maxime animi excepturi a dignissimos doloribus, 
            inventore sed ratione, ducimus atque earum maiores tenetur officia commodi dicta tempora consequatur non nesciunt ipsam, 
            consequuntur quia fuga aspernatur impedit et? Natus, earum.</p>
            <blockquote>
            Earum, quisquam, fugit? Numquam dolor magni nisi? Suscipit odit, ipsam iusto enim culpa, 
            temporibus vero possimus error voluptates sequi.
            </blockquote>
            <p>Earum, quisquam, fugit? Numquam dolor magni nisi? Suscipit odit, ipsam iusto enim culpa, 
            temporibus vero possimus error voluptates sequi. Iusto ipsam, nihil? Eveniet modi maxime animi excepturi a dignissimos doloribus, 
            inventore sed ratione, ducimus atque earum maiores tenetur officia commodi dicta tempora consequatur non nesciunt ipsam, 
            consequuntur quia fuga aspernatur impedit et? Natus, earum.</p>
            <blockquote>
            Earum, quisquam, fugit? Numquam dolor magni nisi? Suscipit odit, ipsam iusto enim culpa, 
            temporibus vero possimus error voluptates sequi.
            </blockquote><br>
            Thanks<br>
            Mark`

    },
    {
      sender: {
        name: 'Laze Apostolski',
        photo: 'assets/images/face-4.jpg'
      },
      date: new Date('27/5/2020'),
      selected: false,
      subject: 'New order informations',
      message: `<p>Natus consequuntur perspiciatis esse beatae illo quos eaque.</p>
            <p>Earum, quisquam, fugit? Numquam dolor magni nisi? Suscipit odit, ipsam iusto enim culpa, 
            temporibus vero possimus error voluptates sequi. Iusto ipsam, nihil? Eveniet modi maxime animi excepturi a dignissimos doloribus, 
            inventore sed ratione, ducimus atque earum maiores tenetur officia commodi dicta tempora consequatur non nesciunt ipsam, 
            consequuntur quia fuga aspernatur impedit et? Natus, earum.</p>
            <blockquote>
            Earum, quisquam, fugit? Numquam dolor magni nisi? Suscipit odit, ipsam iusto enim culpa, 
            temporibus vero possimus error voluptates sequi.
            </blockquote>
            <p>Earum, quisquam, fugit? Numquam dolor magni nisi? Suscipit odit, ipsam iusto enim culpa, 
            temporibus vero possimus error voluptates sequi. Iusto ipsam, nihil? Eveniet modi maxime animi excepturi a dignissimos doloribus, 
            inventore sed ratione, ducimus atque earum maiores tenetur officia commodi dicta tempora consequatur non nesciunt ipsam, 
            consequuntur quia fuga aspernatur impedit et? Natus, earum.</p><br>
            Thanks<br>
            Jhone`

    },
    {
      sender: {
        name: 'Marko Apostolski',
        photo: 'assets/images/face-1.jpg'
      },
      date: new Date('19/11/2018'),
      selected: false,
      subject: 'Welcome to Angular sophia',
      message: `<p>Natus consequuntur perspiciatis esse beatae illo quos eaque.</p>
            <p>Earum, quisquam, fugit? Numquam dolor magni nisi? Suscipit odit, ipsam iusto enim culpa, 
            temporibus vero possimus error voluptates sequi. Iusto ipsam, nihil? Eveniet modi maxime animi excepturi a dignissimos doloribus, 
            inventore sed ratione, ducimus atque earum maiores tenetur officia commodi dicta tempora consequatur non nesciunt ipsam, 
            consequuntur quia fuga aspernatur impedit et? Natus, earum.</p>
            <blockquote>
            Earum, quisquam, fugit? Numquam dolor magni nisi? Suscipit odit, ipsam iusto enim culpa, 
            temporibus vero possimus error voluptates sequi.
            </blockquote>
            <p>Earum, quisquam, fugit? Numquam dolor magni nisi? Suscipit odit, ipsam iusto enim culpa, 
            temporibus vero possimus error voluptates sequi. Iusto ipsam, nihil? Eveniet modi maxime animi excepturi a dignissimos doloribus, 
            inventore sed ratione, ducimus atque earum maiores tenetur officia commodi dicta tempora consequatur non nesciunt ipsam, 
            consequuntur quia fuga aspernatur impedit et? Natus, earum.</p><br>
            Thanks<br>
            Jhone`
    },
    {
      sender: {
        name: 'Petar Dudevski',
        photo: 'assets/images/face-2.jpg'
      },
      date: new Date('11/4/2018'),
      selected: false,
      subject: 'Confirm your email address',
      message: `<p>Natus consequuntur perspiciatis esse beatae illo quos eaque.</p>
            <p>Earum, quisquam, fugit? Numquam dolor magni nisi? Suscipit odit, ipsam iusto enim culpa, 
            temporibus vero possimus error voluptates sequi. Iusto ipsam, nihil? Eveniet modi maxime animi excepturi a dignissimos doloribus, 
            inventore sed ratione, ducimus atque earum maiores tenetur officia commodi dicta tempora consequatur non nesciunt ipsam, 
            consequuntur quia fuga aspernatur impedit et? Natus, earum.</p>
            <blockquote>
            Earum, quisquam, fugit? Numquam dolor magni nisi? Suscipit odit, ipsam iusto enim culpa, 
            temporibus vero possimus error voluptates sequi.
            </blockquote>
            <p>Earum, quisquam, fugit? Numquam dolor magni nisi? Suscipit odit, ipsam iusto enim culpa, 
            temporibus vero possimus error voluptates sequi. Iusto ipsam, nihil? Eveniet modi maxime animi excepturi a dignissimos doloribus, 
            inventore sed ratione, ducimus atque earum maiores tenetur officia commodi dicta tempora consequatur non nesciunt ipsam, 
            consequuntur quia fuga aspernatur impedit et? Natus, earum.</p>
            <blockquote>
            Earum, quisquam, fugit? Numquam dolor magni nisi? Suscipit odit, ipsam iusto enim culpa, 
            temporibus vero possimus error voluptates sequi.
            </blockquote><br>
            Thanks<br>
            Mark`

    },
    {
      sender: {
        name: 'Sofi Apostolska',
        photo: 'assets/images/face-4.jpg'
      },
      date: new Date('05/8/2019'),
      selected: false,
      subject: 'New order informations',
      message: `<p>Natus consequuntur perspiciatis esse beatae illo quos eaque.</p>
            <p>Earum, quisquam, fugit? Numquam dolor magni nisi? Suscipit odit, ipsam iusto enim culpa, 
            temporibus vero possimus error voluptates sequi. Iusto ipsam, nihil? Eveniet modi maxime animi excepturi a dignissimos doloribus, 
            inventore sed ratione, ducimus atque earum maiores tenetur officia commodi dicta tempora consequatur non nesciunt ipsam, 
            consequuntur quia fuga aspernatur impedit et? Natus, earum.</p>
            <blockquote>
            Earum, quisquam, fugit? Numquam dolor magni nisi? Suscipit odit, ipsam iusto enim culpa, 
            temporibus vero possimus error voluptates sequi.
            </blockquote>
            <p>Earum, quisquam, fugit? Numquam dolor magni nisi? Suscipit odit, ipsam iusto enim culpa, 
            temporibus vero possimus error voluptates sequi. Iusto ipsam, nihil? Eveniet modi maxime animi excepturi a dignissimos doloribus, 
            inventore sed ratione, ducimus atque earum maiores tenetur officia commodi dicta tempora consequatur non nesciunt ipsam, 
            consequuntur quia fuga aspernatur impedit et? Natus, earum.</p><br>
            Thanks<br>
            Jhone`

    },
    {
      sender: {
        name: 'David Dudevski',
        photo: 'assets/images/face-2.jpg'
      },
      date: new Date('24/1/2019'),
      selected: false,
      subject: 'Confirm your email address',
      message: `<p>Natus consequuntur perspiciatis esse beatae illo quos eaque.</p>
            <p>Earum, quisquam, fugit? Numquam dolor magni nisi? Suscipit odit, ipsam iusto enim culpa, 
            temporibus vero possimus error voluptates sequi. Iusto ipsam, nihil? Eveniet modi maxime animi excepturi a dignissimos doloribus, 
            inventore sed ratione, ducimus atque earum maiores tenetur officia commodi dicta tempora consequatur non nesciunt ipsam, 
            consequuntur quia fuga aspernatur impedit et? Natus, earum.</p>
            <blockquote>
            Earum, quisquam, fugit? Numquam dolor magni nisi? Suscipit odit, ipsam iusto enim culpa, 
            temporibus vero possimus error voluptates sequi.
            </blockquote>
            <p>Earum, quisquam, fugit? Numquam dolor magni nisi? Suscipit odit, ipsam iusto enim culpa, 
            temporibus vero possimus error voluptates sequi. Iusto ipsam, nihil? Eveniet modi maxime animi excepturi a dignissimos doloribus, 
            inventore sed ratione, ducimus atque earum maiores tenetur officia commodi dicta tempora consequatur non nesciunt ipsam, 
            consequuntur quia fuga aspernatur impedit et? Natus, earum.</p>
            <blockquote>
            Earum, quisquam, fugit? Numquam dolor magni nisi? Suscipit odit, ipsam iusto enim culpa, 
            temporibus vero possimus error voluptates sequi.
            </blockquote><br>
            Thanks<br>
            Mark`

    },
    {
      sender: {
        name: 'Irin Malkunson',
        photo: 'assets/images/face-4.jpg'
      },
      date: new Date('11/3/2017'),
      selected: false,
      subject: 'New order informations',
      message: `<p>Natus consequuntur perspiciatis esse beatae illo quos eaque.</p>
            <p>Earum, quisquam, fugit? Numquam dolor magni nisi? Suscipit odit, ipsam iusto enim culpa, 
            temporibus vero possimus error voluptates sequi. Iusto ipsam, nihil? Eveniet modi maxime animi excepturi a dignissimos doloribus, 
            inventore sed ratione, ducimus atque earum maiores tenetur officia commodi dicta tempora consequatur non nesciunt ipsam, 
            consequuntur quia fuga aspernatur impedit et? Natus, earum.</p>
            <blockquote>
            Earum, quisquam, fugit? Numquam dolor magni nisi? Suscipit odit, ipsam iusto enim culpa, 
            temporibus vero possimus error voluptates sequi.
            </blockquote>
            <p>Earum, quisquam, fugit? Numquam dolor magni nisi? Suscipit odit, ipsam iusto enim culpa, 
            temporibus vero possimus error voluptates sequi. Iusto ipsam, nihil? Eveniet modi maxime animi excepturi a dignissimos doloribus, 
            inventore sed ratione, ducimus atque earum maiores tenetur officia commodi dicta tempora consequatur non nesciunt ipsam, 
            consequuntur quia fuga aspernatur impedit et? Natus, earum.</p><br>
            Thanks<br>
            Jhone`

    },
    {
      sender: {
        name: 'Tim Grench',
        photo: 'assets/images/face-2.jpg'
      },
      date: new Date('22/4/2016'),
      selected: false,
      subject: 'Confirm your email address',
      message: `<p>Natus consequuntur perspiciatis esse beatae illo quos eaque.</p>
            <p>Earum, quisquam, fugit? Numquam dolor magni nisi? Suscipit odit, ipsam iusto enim culpa, 
            temporibus vero possimus error voluptates sequi. Iusto ipsam, nihil? Eveniet modi maxime animi excepturi a dignissimos doloribus, 
            inventore sed ratione, ducimus atque earum maiores tenetur officia commodi dicta tempora consequatur non nesciunt ipsam, 
            consequuntur quia fuga aspernatur impedit et? Natus, earum.</p>
            <blockquote>
            Earum, quisquam, fugit? Numquam dolor magni nisi? Suscipit odit, ipsam iusto enim culpa, 
            temporibus vero possimus error voluptates sequi.
            </blockquote>
            <p>Earum, quisquam, fugit? Numquam dolor magni nisi? Suscipit odit, ipsam iusto enim culpa, 
            temporibus vero possimus error voluptates sequi. Iusto ipsam, nihil? Eveniet modi maxime animi excepturi a dignissimos doloribus, 
            inventore sed ratione, ducimus atque earum maiores tenetur officia commodi dicta tempora consequatur non nesciunt ipsam, 
            consequuntur quia fuga aspernatur impedit et? Natus, earum.</p>
            <blockquote>
            Earum, quisquam, fugit? Numquam dolor magni nisi? Suscipit odit, ipsam iusto enim culpa, 
            temporibus vero possimus error voluptates sequi.
            </blockquote><br>
            Thanks<br>
            Mark`

    }
  ]
}