export class OrderDB {
  static orders = [
    {
      id: 1,
      
    }
  ]
}